import { useState, useEffect, useMemo, useCallback } from "react";
import * as XLSX from "xlsx";
import { supabase } from "./supabase.js";

const C = {
  dark: "#1d2235", dark2: "#2f3650", side: "#b9c0d4",
  teal: "#1D9E75", tealBg: "#E1F5EE", tealDk: "#0F6E56",
  page: "#f4f5f7", card: "#ffffff", border: "#e4e5e9",
  text: "#1f2430", sub: "#6b7280", hint: "#9ca3af",
  blue: "#185FA5", blueBg: "#E6F1FB",
  amber: "#854F0B", amberBg: "#FAEEDA",
  red: "#A32D2D", redBg: "#FCEBEB",
  green: "#3B6D11", greenBg: "#EAF3DE",
};

const DELIVERED = ["입고확인", "회수요청", "회수완료"];
const daysSince = (d) => Math.max(0, Math.round((Date.now() - new Date(d)) / 86400000));
const isUnrecovered = (s) => (s.status === "출고완료" || s.status === "입고확인") && daysSince(s.depart_at) >= 7;
const won = (n) => "₩" + (n || 0).toLocaleString();
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : "id-" + Date.now() + Math.random());

const ST = {
  출고완료: { bg: C.blueBg, fg: C.blue }, 입고확인: { bg: C.greenBg, fg: C.green },
  회수요청: { bg: C.amberBg, fg: C.amber }, 회수완료: { bg: "#eef0f3", fg: C.sub }, 미회수: { bg: C.redBg, fg: C.red },
};
const Pill = ({ status }) => {
  const s = ST[status] ?? { bg: C.page, fg: C.sub };
  return <span style={{ fontSize: 11, padding: "2px 9px", borderRadius: 20, background: s.bg, color: s.fg, whiteSpace: "nowrap" }}>{status}</span>;
};
const Metric = ({ label, value, unit, tone }) => {
  const m = { danger: { bg: C.redBg, fg: C.red }, warn: { bg: C.amberBg, fg: C.amber }, info: { bg: C.blueBg, fg: C.blue }, success: { bg: C.greenBg, fg: C.green }, plain: { bg: "#eef0f3", fg: C.text } }[tone] ?? {};
  return (
    <div style={{ background: m.bg, borderRadius: 10, padding: "12px 14px", flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 12, color: tone === "plain" ? C.sub : m.fg }}>{label}</div>
      <div style={{ fontSize: 21, fontWeight: 500, marginTop: 2, color: m.fg }}>{value}{unit && <span style={{ fontSize: 12, color: tone === "plain" ? C.hint : m.fg }}> {unit}</span>}</div>
    </div>
  );
};
const Head = ({ title, sub, action }) => (
  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, flexWrap: "wrap", gap: 8 }}>
    <div><h2 style={{ margin: 0, fontSize: 18, fontWeight: 600 }}>{title}</h2><p style={{ margin: "2px 0 0", fontSize: 12, color: C.hint }}>{sub}</p></div>
    {action}
  </div>
);
const Note = ({ children }) => <p style={{ fontSize: 11, color: C.hint, marginTop: 14, lineHeight: 1.6 }}>{children}</p>;
const tbl = { width: "100%", borderCollapse: "collapse" };
const btnTeal = { fontSize: 12, padding: "8px 14px", borderRadius: 8, border: "none", background: C.teal, color: "#fff", cursor: "pointer", display: "flex", alignItems: "center", gap: 6 };
const btnTealSm = { fontSize: 11, padding: "5px 10px", borderRadius: 7, border: "none", background: C.teal, color: "#fff", cursor: "pointer" };
const btnGhost = { fontSize: 11, padding: "5px 10px", borderRadius: 7, border: `1px solid ${C.border}`, background: "#fff", cursor: "pointer", color: C.text };
const btnGreen = { fontSize: 12, padding: "8px 14px", borderRadius: 8, border: "none", background: C.green, color: "#fff", cursor: "pointer" };
const Td = ({ children, r, b, c }) => <td style={{ padding: "11px 6px", fontSize: 12, textAlign: r ? "right" : "left", fontWeight: b ? 600 : 400, color: c ?? C.text }}>{children}</td>;
const Th = ({ children, r }) => <th style={{ fontSize: 11, color: C.hint, fontWeight: 400, textAlign: r ? "right" : "left", padding: "9px 6px" }}>{children}</th>;
const TYPE_BADGE = { 시공팀: { bg: C.blueBg, fg: C.blue }, 센터: { bg: C.amberBg, fg: C.amber }, 업체: { bg: "#eef0f3", fg: C.sub } };
const TypeBadge = ({ t }) => { const b = TYPE_BADGE[t] || TYPE_BADGE.업체; return <span style={{ fontSize: 11, color: b.fg, background: b.bg, padding: "2px 8px", borderRadius: 20 }}>{t}</span>; };

// ─── 인증 화면 ───────────────────────────────────────────────
function Auth() {
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setBusy(true); setMsg("");
    try {
      if (mode === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email, password: pw });
        if (error) setMsg(error.message);
      } else {
        const { data, error } = await supabase.auth.signUp({ email, password: pw });
        if (error) { setMsg(error.message); }
        else {
          const u = data.user;
          if (u) {
            await supabase.from("profiles").upsert({ id: u.id, name: email.split("@")[0] });
            await supabase.from("user_roles").upsert({ user_id: u.id, role: "협력업체" }, { onConflict: "user_id" });
          }
          if (!data.session) setMsg("가입 완료! 로그인하세요. (로그인이 안 되면 Supabase에서 이메일 인증을 꺼주세요)");
          else setMsg("");
        }
      }
    } catch (e) { setMsg(String(e.message || e)); }
    setBusy(false);
  };

  return (
    <div style={{ minHeight: "100vh", background: C.page, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "system-ui, sans-serif", padding: 16 }}>
      <div style={{ width: "100%", maxWidth: 380 }}>
        <div style={{ background: C.dark, borderRadius: 14, padding: "22px 20px", textAlign: "center", marginBottom: 14 }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 9 }}>
            <div style={{ width: 30, height: 30, borderRadius: 8, background: C.teal, color: "#04342C", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 17 }}>L</div>
            <span style={{ color: "#fff", fontWeight: 600, fontSize: 19 }}>LETUS PMS</span>
          </div>
          <div style={{ color: "#8b93ab", fontSize: 12, marginTop: 6 }}>파렛트 렌탈 수불관리 시스템</div>
        </div>
        <div style={{ background: C.card, borderRadius: 14, padding: 20, border: `1px solid ${C.border}` }}>
          <div style={{ display: "flex", gap: 6, marginBottom: 16, background: "#eef0f3", borderRadius: 10, padding: 4 }}>
            {["login", "signup"].map((m) => (
              <button key={m} onClick={() => { setMode(m); setMsg(""); }} style={{ flex: 1, padding: "8px 0", borderRadius: 8, border: "none", cursor: "pointer", fontSize: 13, fontWeight: 500, background: mode === m ? C.teal : "transparent", color: mode === m ? "#fff" : C.sub }}>
                {m === "login" ? "로그인" : "신규 가입"}
              </button>
            ))}
          </div>
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="이메일" style={{ width: "100%", boxSizing: "border-box", fontSize: 14, padding: "11px 12px", border: `1px solid ${C.border}`, borderRadius: 8, marginBottom: 10 }} />
          <input value={pw} onChange={(e) => setPw(e.target.value)} type="password" placeholder="비밀번호" onKeyDown={(e) => e.key === "Enter" && submit()} style={{ width: "100%", boxSizing: "border-box", fontSize: 14, padding: "11px 12px", border: `1px solid ${C.border}`, borderRadius: 8, marginBottom: 12 }} />
          {msg && <div style={{ fontSize: 12, color: C.red, background: C.redBg, padding: "8px 10px", borderRadius: 8, marginBottom: 12 }}>{msg}</div>}
          <button disabled={busy || !email || !pw} onClick={submit} style={{ width: "100%", background: busy ? "#c7cad1" : C.teal, color: "#fff", border: "none", borderRadius: 10, padding: 12, fontSize: 15, cursor: "pointer" }}>
            {busy ? "처리 중…" : mode === "login" ? "로그인" : "가입하기"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── 메인 앱 ─────────────────────────────────────────────────
export default function App() {
  const [session, setSession] = useState(null);
  const [authReady, setAuthReady] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setAuthReady(true); });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  if (!authReady) return <Splash text="불러오는 중…" />;
  if (!session) return <Auth />;
  return <Shell session={session} />;
}

const Splash = ({ text }) => (
  <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", color: C.sub, fontFamily: "system-ui, sans-serif", fontSize: 14 }}>{text}</div>
);

function Shell({ session }) {
  const [nav, setNav] = useState("현황");
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [palletTypes, setPalletTypes] = useState([]);
  const [prices, setPrices] = useState({});
  const [partners, setPartners] = useState([]);
  const [contracted, setContracted] = useState({});
  const [ships, setShips] = useState([]);
  const [role, setRole] = useState("");
  const [flash, setFlash] = useState(null);

  const loadAll = useCallback(async () => {
    setErr("");
    try {
      const [pt, up, pa, pp, sh, ur] = await Promise.all([
        supabase.from("pallet_type").select("*").order("code"),
        supabase.from("unit_price").select("*"),
        supabase.from("partner").select("*").eq("active", true).order("name"),
        supabase.from("partner_pallet").select("*"),
        supabase.from("shipment").select("*").order("depart_at", { ascending: false }),
        supabase.from("user_roles").select("role").eq("user_id", session.user.id).maybeSingle(),
      ]);
      const firstErr = [pt, up, pa, pp, sh].find((r) => r.error);
      if (firstErr) throw firstErr.error;
      setPalletTypes(pt.data || []);
      const pm = {}; (up.data || []).forEach((r) => { pm[r.pallet_code] = r.price; });
      setPrices(pm);
      setPartners(pa.data || []);
      const cm = {}; (pp.data || []).forEach((r) => { (cm[r.partner_code] = cm[r.partner_code] || []).push(r.pallet_code); });
      setContracted(cm);
      setShips(sh.data || []);
      setRole(ur?.data?.role || "협력업체");
    } catch (e) {
      setErr("데이터를 불러오지 못했어요: " + (e.message || e));
    }
    setLoading(false);
  }, [session.user.id]);

  useEffect(() => { loadAll(); }, [loadAll]);

  const register = async (partner, pallet, qty) => {
    try {
      const { data: slip, error: e1 } = await supabase.rpc("next_slip_no");
      if (e1) throw e1;
      const id = uid();
      const { error: e2 } = await supabase.from("shipment").insert({
        id, slip_no: slip, to_partner: partner.code, to_partner_name: partner.name,
        pallet_code: pallet, qty, status: "출고완료", depart_at: new Date().toISOString(), created_by: session.user.id,
      });
      if (e2) throw e2;
      await supabase.from("movement").insert({
        id: uid(), shipment_id: id, type: "출고", source: "앱", pallet_code: pallet, qty,
        to_partner: partner.code, to_partner_name: partner.name, created_by: session.user.id,
      });
      setFlash(slip); setNav("현황"); loadAll();
    } catch (e) { alert("출고 등록 실패: " + (e.message || e)); }
  };

  const setStatus = async (s, newStatus, mvType) => {
    try {
      const { error } = await supabase.from("shipment").update({ status: newStatus }).eq("id", s.id);
      if (error) throw error;
      if (mvType) await supabase.from("movement").insert({
        id: uid(), shipment_id: s.id, type: mvType, source: "앱", pallet_code: s.pallet_code, qty: s.qty,
        to_partner: s.to_partner, to_partner_name: s.to_partner_name, created_by: session.user.id,
      });
      loadAll();
    } catch (e) { alert("상태 변경 실패: " + (e.message || e)); }
  };

  const addPartner = async (name, type) => {
    try {
      const code = "P" + Date.now().toString().slice(-7);
      const { error } = await supabase.from("partner").insert({ code, name, type });
      if (error) throw error;
      loadAll();
    } catch (e) { alert("거래처 등록 실패: " + (e.message || e)); }
  };

  const bulkAddPartners = async (list) => {
    const existing = new Set(partners.map((p) => p.name));
    const seen = new Set();
    const toAdd = [];
    list.forEach((r) => {
      const nm = (r.name || "").trim();
      if (!nm || existing.has(nm) || seen.has(nm)) return;
      seen.add(nm);
      toAdd.push({ code: "P" + Date.now().toString().slice(-6) + toAdd.length, name: nm, type: r.type });
    });
    if (toAdd.length) {
      const { error } = await supabase.from("partner").insert(toAdd);
      if (error) throw error;
    }
    await loadAll();
    return { added: toAdd.length, skipped: list.length - toAdd.length };
  };

  const items = [
    { key: "현황", label: "수불 현황" }, { key: "출고", label: "출고 등록" },
    { key: "확인", label: "입고확인" }, { key: "회수", label: "회수 관리" },
    { key: "정산", label: "정산" }, { key: "마스터", label: "거래처·단가" },
  ];

  const partnersFull = partners.map((p) => ({ ...p, contracted: contracted[p.code] || [] }));

  return (
    <div style={{ display: "flex", minHeight: "100vh", fontFamily: "system-ui, sans-serif", color: C.text, background: C.page }}>
      {/* 데스크톱 사이드바 */}
      <aside style={{ width: 176, background: C.dark, padding: "16px 12px", flexShrink: 0 }} className="lp-side">
        <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "4px 8px 16px" }}>
          <div style={{ width: 24, height: 24, borderRadius: 6, background: C.teal, color: "#04342C", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 600, fontSize: 14 }}>L</div>
          <span style={{ color: "#fff", fontWeight: 600, fontSize: 15 }}>LETUS<span style={{ color: C.teal }}> PMS</span></span>
        </div>
        {items.map((it) => {
          const on = nav === it.key;
          return <button key={it.key} onClick={() => setNav(it.key)} style={{ display: "block", width: "100%", padding: "9px 12px", marginBottom: 3, borderRadius: 8, border: "none", cursor: "pointer", textAlign: "left", fontSize: 13, background: on ? C.dark2 : "transparent", color: on ? "#fff" : C.side }}>{it.label}</button>;
        })}
        <div style={{ marginTop: 18, padding: "0 8px" }}>
          <div style={{ color: "#6b7494", fontSize: 11 }}>{session.user.email}</div>
          <div style={{ color: C.teal, fontSize: 11, marginBottom: 8 }}>{role}</div>
          <button onClick={() => supabase.auth.signOut()} style={{ fontSize: 11, color: C.side, background: "transparent", border: "1px solid #3a4258", borderRadius: 6, padding: "5px 9px", cursor: "pointer" }}>로그아웃</button>
        </div>
      </aside>

      <main style={{ flex: 1, minWidth: 0, padding: "20px 18px 80px", overflow: "auto" }}>
        {loading ? <Splash text="데이터 불러오는 중…" /> : err ? (
          <div style={{ background: C.redBg, color: C.red, padding: 16, borderRadius: 10, fontSize: 13 }}>
            {err}<br /><br />혹시 supabase.js에 anon key를 안 넣었거나, 쓰기 권한(RLS) 설정이 필요할 수 있어요. 화면을 캡처해서 Claude에게 물어보세요.
          </div>
        ) : (
          <>
            {nav === "현황" && <Dashboard {...{ ships, flash, setStatus, setNav }} />}
            {nav === "출고" && <Outbound partners={partnersFull} palletTypes={palletTypes} onRegister={register} />}
            {nav === "확인" && <Confirm {...{ ships, setStatus }} />}
            {nav === "회수" && <Recovery {...{ ships, setStatus }} />}
            {nav === "정산" && <Billing {...{ ships, prices }} />}
            {nav === "마스터" && <Master {...{ palletTypes, prices, partners: partnersFull, addPartner, bulkAddPartners }} />}
          </>
        )}
      </main>

      {/* 모바일 하단 탭바 */}
      <nav className="lp-bottom" style={{ position: "fixed", bottom: 0, left: 0, right: 0, background: C.dark, display: "none", justifyContent: "space-around", padding: "8px 4px", zIndex: 10 }}>
        {items.slice(0, 5).map((it) => {
          const on = nav === it.key;
          return <button key={it.key} onClick={() => setNav(it.key)} style={{ background: "none", border: "none", color: on ? C.teal : C.side, fontSize: 11, cursor: "pointer", padding: "2px 6px" }}>{it.label}</button>;
        })}
      </nav>

      <style>{`
        @media (max-width: 720px) {
          .lp-side { display: none !important; }
          .lp-bottom { display: flex !important; }
        }
      `}</style>
    </div>
  );
}

function Tabs({ tabs, tab, setTab, count }) {
  return (
    <div style={{ display: "flex", gap: 16, borderBottom: `1px solid ${C.border}`, marginBottom: 6, flexWrap: "wrap" }}>
      {tabs.map((t) => { const on = tab === t; return <button key={t} onClick={() => setTab(t)} style={{ background: "none", border: "none", cursor: "pointer", padding: "7px 2px", fontSize: 13, color: on ? C.text : C.sub, borderBottom: `2px solid ${on ? C.teal : "transparent"}` }}>{t} <span style={{ color: C.hint }}>{count(t)}</span></button>; })}
    </div>
  );
}

function Dashboard({ ships, flash, setStatus, setNav }) {
  const [tab, setTab] = useState("전체");
  const tabs = ["전체", "출고완료", "입고확인", "회수요청", "미회수"];
  const todayStr = new Date().toISOString().slice(0, 10);
  const today = ships.filter((s) => (s.depart_at || "").slice(0, 10) === todayStr).reduce((a, s) => a + s.qty, 0);
  const unrec = ships.filter(isUnrecovered).reduce((a, s) => a + s.qty, 0);
  const waiting = ships.filter((s) => s.status === "출고완료").length;
  const filtered = tab === "전체" ? ships : tab === "미회수" ? ships.filter(isUnrecovered) : ships.filter((s) => s.status === tab);

  return (
    <>
      <Head title="수불 현황" sub={new Date().toLocaleDateString("ko-KR")} action={<button onClick={() => setNav("출고")} style={btnTeal}>+ 출고 등록</button>} />
      {flash && <div style={{ background: C.greenBg, color: C.green, fontSize: 13, padding: "9px 14px", borderRadius: 8, marginBottom: 14 }}>✓ 출고 등록 완료 — 전표 {flash} 발행</div>}
      <div style={{ display: "flex", gap: 10, marginBottom: 18, flexWrap: "wrap" }}>
        <Metric label="금일 출고" value={today} unit="장" tone="plain" />
        <Metric label="미회수 7일↑" value={unrec} unit="장" tone="danger" />
        <Metric label="입고확인 대기" value={waiting} unit="건" tone="warn" />
        <Metric label="총 건수" value={ships.length} unit="건" tone="plain" />
      </div>
      <Tabs tabs={tabs} tab={tab} setTab={setTab} count={(t) => t === "전체" ? ships.length : t === "미회수" ? ships.filter(isUnrecovered).length : ships.filter((s) => s.status === t).length} />
      <div style={{ overflowX: "auto" }}>
        <table style={tbl}>
          <thead><tr><Th>상태</Th><Th>전표</Th><Th>유형</Th><Th r>수량</Th><Th>거래처</Th><Th>경과</Th><Th>조치</Th></tr></thead>
          <tbody>
            {filtered.map((s) => {
              const danger = isUnrecovered(s); const d = daysSince(s.depart_at);
              return (
                <tr key={s.id} style={{ borderTop: `1px solid ${C.border}` }}>
                  <Td><Pill status={danger ? "미회수" : s.status} /></Td>
                  <Td c={C.sub}>{s.slip_no}</Td><Td>{s.pallet_code}</Td><Td r>{s.qty}</Td><Td>{s.to_partner_name}</Td>
                  <Td c={danger ? C.red : s.status === "회수완료" ? C.hint : C.text} b={danger}>{s.status === "회수완료" ? "—" : d + "일"}</Td>
                  <Td>
                    {s.status === "출고완료" && <button onClick={() => setStatus(s, "입고확인", "입고확인")} style={btnGhost}>입고확인</button>}
                    {s.status === "입고확인" && <button onClick={() => setStatus(s, "회수요청", "회수요청")} style={btnGhost}>회수요청</button>}
                    {s.status === "회수요청" && <button onClick={() => setStatus(s, "회수완료", "회수")} style={btnTealSm}>회수완료</button>}
                    {s.status === "회수완료" && <span style={{ color: C.green }}>✓</span>}
                  </Td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <Note>7일 이상 회수 안 된 건은 미회수(빨강)로 자동 분류돼요. 조치 버튼으로 상태가 흐르고 Supabase에 바로 저장됩니다.</Note>
    </>
  );
}

function Outbound({ partners, palletTypes, onRegister }) {
  const [q, setQ] = useState(""); const [sel, setSel] = useState(null);
  const [pallet, setPallet] = useState(null); const [qty, setQty] = useState(20);
  const [open, setOpen] = useState(false); const [busy, setBusy] = useState(false);
  const matches = partners.filter((p) => p.name.includes(q) || (p.type || "").includes(q)).slice(0, 6);
  const pick = (p) => { setSel(p); setQ(""); setOpen(false); };

  return (
    <>
      <Head title="출고 등록" sub="거래처를 검색해서 고르고, 유형·수량 입력" />
      <div style={{ maxWidth: 480, background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: 20 }}>
        <div style={{ fontSize: 13, color: C.sub, marginBottom: 7 }}>거래처 <span style={{ color: C.hint, fontSize: 11 }}>· 검색</span></div>
        {!sel ? (
          <div style={{ position: "relative", marginBottom: 18 }}>
            <input value={q} onChange={(e) => { setQ(e.target.value); setOpen(true); }} onFocus={() => setOpen(true)} placeholder="예: 쿠팡, 시공팀, 이케아…" style={{ width: "100%", boxSizing: "border-box", fontSize: 14, padding: "10px 12px", border: `1px solid ${C.border}`, borderRadius: 8 }} />
            {open && (
              <div style={{ position: "absolute", top: 44, left: 0, right: 0, background: "#fff", border: `1px solid ${C.border}`, borderRadius: 8, zIndex: 5, maxHeight: 240, overflow: "auto" }}>
                {matches.length === 0 && <div style={{ padding: "10px 12px", fontSize: 13, color: C.hint }}>일치하는 거래처 없음</div>}
                {matches.map((p) => (
                  <button key={p.code} onClick={() => pick(p)} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%", padding: "10px 12px", border: "none", borderBottom: `1px solid ${C.border}`, background: "#fff", cursor: "pointer", textAlign: "left" }}>
                    <span style={{ fontSize: 13 }}>{p.name}</span>
                    <TypeBadge t={p.type} />
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", border: `1px solid ${C.teal}`, background: C.tealBg, borderRadius: 8, padding: "10px 12px", marginBottom: 18 }}>
            <span style={{ fontSize: 14, color: C.tealDk, fontWeight: 600 }}>{sel.name} <span style={{ fontSize: 11, fontWeight: 400 }}>· {sel.type}</span></span>
            <button onClick={() => setSel(null)} style={{ background: "none", border: "none", cursor: "pointer", color: C.tealDk, fontSize: 16 }}>✕</button>
          </div>
        )}

        <div style={{ fontSize: 13, color: C.sub, marginBottom: 7 }}>파렛트 유형 <span style={{ color: C.hint, fontSize: 11 }}>· 전체 유형 선택 가능</span></div>
        <div style={{ display: "flex", gap: 8, marginBottom: 18, minHeight: 44, flexWrap: "wrap" }}>
          {palletTypes.map((p) => {
            const on = pallet === p.code;
            return <button key={p.code} onClick={() => setPallet(p.code)} style={{ minWidth: 70, fontSize: 14, padding: "11px 14px", borderRadius: 8, cursor: "pointer", border: on ? `1px solid ${C.teal}` : `1px solid ${C.border}`, background: on ? C.tealBg : "#fff", color: on ? C.tealDk : C.text, fontWeight: on ? 600 : 400 }}>{p.code}</button>;
          })}
        </div>

        <div style={{ fontSize: 13, color: C.sub, marginBottom: 7 }}>수량</div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", border: `1px solid ${C.border}`, borderRadius: 8, padding: "6px 16px", marginBottom: 18 }}>
          <button onClick={() => setQty(Math.max(1, qty - 1))} style={{ background: "none", border: "none", fontSize: 22, color: C.sub, cursor: "pointer" }}>−</button>
          <span style={{ fontSize: 20, fontWeight: 600 }}>{qty}</span>
          <button onClick={() => setQty(qty + 1)} style={{ background: "none", border: "none", fontSize: 22, color: C.teal, cursor: "pointer" }}>+</button>
        </div>

        <button disabled={!sel || !pallet || busy} onClick={async () => { setBusy(true); await onRegister(sel, pallet, qty); setBusy(false); }} style={{ width: "100%", background: (!sel || !pallet || busy) ? "#c7cad1" : C.teal, color: "#fff", border: "none", borderRadius: 10, padding: 13, fontSize: 15, cursor: "pointer" }}>{busy ? "등록 중…" : "출고 등록"}</button>
        <p style={{ textAlign: "center", fontSize: 11, color: C.hint, marginTop: 10 }}>등록 즉시 전표 자동 발행 · Supabase에 저장</p>
      </div>
    </>
  );
}

function Confirm({ ships, setStatus }) {
  const pending = ships.filter((s) => s.status === "출고완료");
  return (
    <>
      <Head title="입고확인" sub="도착지에서 받는 사람이 확인하는 화면" />
      {pending.length === 0 ? <div style={{ padding: 40, textAlign: "center", color: C.hint, fontSize: 13 }}>확인 대기 중인 출고가 없어요.</div> : (
        <div style={{ display: "grid", gap: 12, maxWidth: 560 }}>
          {pending.map((s) => (
            <div key={s.id} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: 16, display: "flex", alignItems: "center", gap: 14 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 600 }}>{s.to_partner_name}</div>
                <div style={{ fontSize: 12, color: C.sub }}>{s.slip_no} · {s.pallet_code} · {s.qty}장</div>
              </div>
              <button onClick={() => setStatus(s, "입고확인", "입고확인")} style={btnTeal}>✓ 확인</button>
            </div>
          ))}
        </div>
      )}
      <Note>확인을 누르면 입고확인으로 바뀌고 수불 현황·정산에 즉시 반영돼요.</Note>
    </>
  );
}

function Recovery({ ships, setStatus }) {
  const list = ships.filter((s) => s.status === "입고확인" || s.status === "회수요청");
  const total = list.reduce((a, s) => a + s.qty, 0);
  const over7 = ships.filter((s) => s.status === "입고확인" && daysSince(s.depart_at) >= 7).reduce((a, s) => a + s.qty, 0);
  const over14 = ships.filter((s) => s.status === "입고확인" && daysSince(s.depart_at) >= 14).reduce((a, s) => a + s.qty, 0);
  const inProg = ships.filter((s) => s.status === "회수요청").length;
  return (
    <>
      <Head title="회수 관리" sub="입고 완료 후 회수 대상 · 경과일 기준" />
      <div style={{ display: "flex", gap: 10, marginBottom: 18, flexWrap: "wrap" }}>
        <Metric label="회수 대상" value={total} unit="장" tone="plain" />
        <Metric label="7일↑" value={over7} unit="장" tone="warn" />
        <Metric label="14일↑ 위험" value={over14} unit="장" tone="danger" />
        <Metric label="회수요청 진행중" value={inProg} unit="건" tone="plain" />
      </div>
      <div style={{ overflowX: "auto" }}>
        <table style={tbl}>
          <thead><tr><Th>거래처</Th><Th>유형·수량</Th><Th>경과</Th><Th>조치</Th></tr></thead>
          <tbody>
            {list.map((s) => {
              const d = daysSince(s.depart_at); const danger = d >= 14;
              return (
                <tr key={s.id} style={{ borderTop: `1px solid ${C.border}` }}>
                  <Td>{s.to_partner_name}</Td><Td>{s.pallet_code} · {s.qty}</Td>
                  <Td c={danger ? C.red : d >= 7 ? C.amber : C.text} b={d >= 7}>{d}일</Td>
                  <Td>{s.status === "입고확인" ? <button onClick={() => setStatus(s, "회수요청", "회수요청")} style={btnTealSm}>회수요청</button> : <span style={{ fontSize: 11, padding: "3px 9px", borderRadius: 7, background: C.amberBg, color: C.amber }}>요청완료</span>}</Td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <Note>14일↑은 위험(빨강)으로 분류돼요. 회수요청을 누르면 상태가 바뀌고 Supabase에 저장됩니다.</Note>
    </>
  );
}

function Billing({ ships, prices }) {
  const lines = useMemo(() => {
    const map = {};
    ships.filter((s) => DELIVERED.includes(s.status)).forEach((s) => {
      const k = s.to_partner_name + "|" + s.pallet_code;
      map[k] = map[k] ? { ...map[k], qty: map[k].qty + s.qty } : { partner: s.to_partner_name, pallet: s.pallet_code, qty: s.qty };
    });
    return Object.values(map).map((l) => ({ ...l, price: prices[l.pallet] || 0, amount: l.qty * (prices[l.pallet] || 0) }));
  }, [ships, prices]);
  const total = lines.reduce((a, l) => a + l.amount, 0);
  return (
    <>
      <Head title="정산" sub={new Date().toISOString().slice(0, 7) + " · 입고확인 이상 집계"} action={<button style={btnGreen}>정산 확정</button>} />
      <div style={{ display: "flex", gap: 10, marginBottom: 18, flexWrap: "wrap" }}>
        <Metric label="정산 거래처" value={new Set(lines.map((l) => l.partner)).size} unit="곳" tone="plain" />
        <Metric label="청구 총액" value={won(total)} tone="plain" />
        <Metric label="단가 적용" value="자동" tone="info" />
        <Metric label="정합성" value="자동" tone="success" />
      </div>
      <div style={{ overflowX: "auto" }}>
        <table style={tbl}>
          <thead><tr><Th>거래처</Th><Th>유형</Th><Th r>수량</Th><Th r>단가</Th><Th r>금액</Th></tr></thead>
          <tbody>
            {lines.map((l, i) => (
              <tr key={i} style={{ borderTop: `1px solid ${C.border}` }}>
                <Td>{l.partner}</Td><Td>{l.pallet}</Td><Td r>{l.qty}</Td><Td r>{l.price.toLocaleString()}</Td><Td r b>{l.amount.toLocaleString()}</Td>
              </tr>
            ))}
            <tr style={{ borderTop: `1px solid ${C.border}`, background: "#eef0f3" }}>
              <td colSpan={4} style={{ padding: "11px 6px", fontSize: 12, fontWeight: 600 }}>합계</td>
              <td style={{ padding: "11px 6px", fontSize: 12, fontWeight: 600, textAlign: "right" }}>{won(total)}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <Note>입고확인 이상 상태만 집계 + 거래처·단가의 단가가 자동 적용돼요.</Note>
    </>
  );
}

function Master({ palletTypes, prices, partners, addPartner, bulkAddPartners }) {
  const [name, setName] = useState(""); const [type, setType] = useState("업체");
  const [pq, setPq] = useState(""); const [pf, setPf] = useState("전체");
  const [preview, setPreview] = useState([]); const [busy, setBusy] = useState(false); const [msg, setMsg] = useState("");
  const filtered = partners.filter((p) => (pf === "전체" || p.type === pf) && (p.name.includes(pq) || pq === ""));

  const normType = (v) => { const s = String(v || "").trim(); if (s.includes("시공")) return "시공팀"; if (s.includes("센터")) return "센터"; return "업체"; };
  const pickName = (r) => r["거래처명"] ?? r["거래처"] ?? r["이름"] ?? r["업체명"] ?? r["name"] ?? r["NAME"] ?? Object.values(r)[0] ?? "";
  const onFile = async (e) => {
    const file = e.target.files?.[0]; if (!file) return;
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: "array" });
      const json = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { defval: "" });
      const rows = json.map((r) => ({ name: String(pickName(r)).trim(), type: normType(r["구분"] ?? r["유형"] ?? r["type"]) })).filter((r) => r.name);
      setPreview(rows); setMsg(rows.length === 0 ? "읽을 데이터가 없어요. 첫 행에 '거래처명' 열이 있는지 확인하세요." : "");
    } catch (err) { setMsg("엑셀을 읽지 못했어요: " + (err.message || err)); }
    e.target.value = "";
  };
  const doImport = async () => {
    setBusy(true);
    try { const res = await bulkAddPartners(preview); setMsg(`완료: ${res.added}개 등록, ${res.skipped}개 건너뜀(중복·빈값)`); setPreview([]); }
    catch (e) { setMsg("등록 실패: " + (e.message || e)); }
    setBusy(false);
  };
  return (
    <>
      <Head title="거래처 · 단가" sub="거래처를 등록하면 출고 등록 검색에 바로 잡혀요" />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 16 }}>
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: "14px 16px" }}>
          <h3 style={{ margin: "0 0 8px", fontSize: 14, fontWeight: 600 }}>파렛트 유형 · 단가</h3>
          <table style={tbl}>
            <thead><tr><Th>유형</Th><Th>용도</Th><Th r>단가(원)</Th></tr></thead>
            <tbody>
              {palletTypes.map((p) => (
                <tr key={p.code} style={{ borderTop: `1px solid ${C.border}` }}>
                  <Td b>{p.code}</Td><Td c={C.sub}>{p.usage}</Td><Td r>{(prices[p.code] || 0).toLocaleString()}</Td>
                </tr>
              ))}
            </tbody>
          </table>
          <p style={{ fontSize: 11, color: C.hint, marginTop: 10 }}>모든 파렛트 유형은 거래처 구분 없이 어디로든 출고할 수 있어요.</p>
        </div>
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: "14px 16px" }}>
          <h3 style={{ margin: "0 0 10px", fontSize: 14, fontWeight: 600 }}>거래처 <span style={{ color: C.hint, fontWeight: 400 }}>({filtered.length}/{partners.length})</span></h3>
          <input value={pq} onChange={(e) => setPq(e.target.value)} placeholder="이름으로 검색…" style={{ width: "100%", boxSizing: "border-box", fontSize: 13, padding: "8px 10px", border: `1px solid ${C.border}`, borderRadius: 8, marginBottom: 8 }} />
          <div style={{ display: "flex", gap: 6, marginBottom: 10, flexWrap: "wrap" }}>
            {["전체", "업체", "시공팀", "센터"].map((f) => {
              const on = pf === f;
              return <button key={f} onClick={() => setPf(f)} style={{ fontSize: 12, padding: "4px 11px", borderRadius: 20, cursor: "pointer", border: on ? "none" : `1px solid ${C.border}`, background: on ? C.teal : "#fff", color: on ? "#fff" : C.sub }}>{f}</button>;
            })}
          </div>
          <div style={{ maxHeight: 240, overflow: "auto", marginBottom: 12 }}>
            <table style={tbl}><tbody>
              {filtered.map((p) => (
                <tr key={p.code} style={{ borderTop: `1px solid ${C.border}` }}>
                  <Td>{p.name}</Td>
                  <Td><TypeBadge t={p.type} /></Td>
                </tr>
              ))}
              {filtered.length === 0 && <tr><td colSpan={2} style={{ padding: "16px 6px", fontSize: 12, color: C.hint, textAlign: "center" }}>검색 결과 없음</td></tr>}
            </tbody></table>
          </div>
          <div style={{ borderTop: `1px solid ${C.border}`, paddingTop: 12 }}>
            <div style={{ fontSize: 12, color: C.sub, marginBottom: 7 }}>새 거래처 등록</div>
            <div style={{ display: "flex", gap: 6, marginBottom: 8 }}>
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="거래처명" style={{ flex: 1, minWidth: 0, fontSize: 13, padding: "7px 9px", border: `1px solid ${C.border}`, borderRadius: 6 }} />
              <select value={type} onChange={(e) => setType(e.target.value)} style={{ fontSize: 13, padding: "7px 9px", border: `1px solid ${C.border}`, borderRadius: 6 }}><option>업체</option><option>시공팀</option><option>센터</option></select>
            </div>
            <button onClick={async () => { if (name) { await addPartner(name, type); setName(""); } }} disabled={!name} style={{ width: "100%", fontSize: 13, padding: 9, borderRadius: 8, border: "none", cursor: "pointer", background: !name ? "#c7cad1" : C.teal, color: "#fff" }}>등록</button>
          </div>
          <div style={{ borderTop: `1px solid ${C.border}`, paddingTop: 12, marginTop: 12 }}>
            <div style={{ fontSize: 12, color: C.sub, marginBottom: 7 }}>엑셀 일괄 등록</div>
            <label style={{ display: "inline-block", fontSize: 13, padding: "9px 14px", borderRadius: 8, border: `1px dashed ${C.teal}`, cursor: "pointer", color: C.tealDk, background: C.tealBg }}>
              📄 엑셀 파일 선택 (.xlsx)
              <input type="file" accept=".xlsx,.xls" onChange={onFile} style={{ display: "none" }} />
            </label>
            {preview.length > 0 && (
              <div style={{ marginTop: 10, background: "#eef0f3", borderRadius: 8, padding: "10px 12px" }}>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{preview.length}개 행을 읽었어요. 등록할까요?</div>
                <div style={{ fontSize: 11, color: C.hint, margin: "4px 0 8px" }}>예: {preview.slice(0, 3).map((r) => `${r.name}(${r.type})`).join(", ")}{preview.length > 3 ? " …" : ""}</div>
                <div style={{ display: "flex", gap: 6 }}>
                  <button onClick={doImport} disabled={busy} style={{ ...btnTealSm, padding: "7px 16px" }}>{busy ? "등록 중…" : "등록"}</button>
                  <button onClick={() => setPreview([])} style={{ ...btnGhost, padding: "7px 16px" }}>취소</button>
                </div>
              </div>
            )}
            {msg && <div style={{ fontSize: 12, color: msg.startsWith("완료") ? C.green : C.red, marginTop: 8 }}>{msg}</div>}
            <div style={{ fontSize: 11, color: C.hint, marginTop: 8, lineHeight: 1.6 }}>양식: 첫 행에 <b>거래처명</b>, <b>구분</b>(업체/시공팀/센터) 열. 구분이 없으면 업체로 처리돼요. 이미 있는 이름은 자동 건너뜀.</div>
          </div>
        </div>
      </div>
      <Note>거래처가 많아져도 검색·구분 필터로 빠르게 찾을 수 있어요. 나중에 엑셀 일괄 등록도 붙일 수 있어요.</Note>
    </>
  );
}
